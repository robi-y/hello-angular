import { Observable } from 'rxjs/Rx';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthenticationService implements CanActivate {
  private isLoggedIn = false;

  logIn(): Promise<boolean> {
    this.isLoggedIn = true;
    return Promise.resolve(true);
  }

  logOut(): Promise<boolean> {
    this.isLoggedIn = false;
    return Promise.resolve(true);
  }

  isAuthenticated(): Promise<boolean> {
    return Promise.resolve(this.isLoggedIn);
  }

  constructor() { }


  public canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    console.log('Guard is testing. Result = ' + this.isLoggedIn);
    return this.isLoggedIn;
  }
}
