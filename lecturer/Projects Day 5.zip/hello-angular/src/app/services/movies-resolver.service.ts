import { MoviesService } from './movies.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Movie } from '../model/movie';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class MoviesResolver implements Resolve<Movie[]> {
  constructor(private service: MoviesService) {}

  public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Movie[]> | Promise<Movie[]> | Movie[] {
    console.log('Resolving movies');
    return this.service.getMoviesSlow();
  }
}
