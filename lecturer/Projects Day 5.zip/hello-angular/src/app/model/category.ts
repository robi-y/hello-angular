export enum Category {
  action,
  comedy,
  drama,
  documentary,
  thriller,
  animation
}
