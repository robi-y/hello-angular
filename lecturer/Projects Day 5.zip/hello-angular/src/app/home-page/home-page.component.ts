import { AuthenticationService } from '../services/authentication.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  isAuthenticated = false;

  constructor(
    private router: Router,
    private authentication: AuthenticationService
  ) { }

  ngOnInit() {
    this.checkAuthentication();
  }

  checkAuthentication(): void {
    this.authentication.isAuthenticated()
    .then(r => {
      this.isAuthenticated = r;
    });
  }

  goToMovies(): void {
    this.router.navigate(['/', 'movies']);
  }

  logIn(): void {
    this.authentication.logIn()
        .then(r => {
          this.checkAuthentication();
        });
  }

  logOut(): void {
    this.authentication.logOut()
        .then(r => {
          this.checkAuthentication();
        });
  }
}
