import { MoviesService } from '../services/movies.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Movie } from './../model/movie';

@Component({
  selector: 'app-movies-list',
  templateUrl: 'app.movies-list.component.html',
  styleUrls: ['app.movies-list.component.css']
})
export class MoviesListComponent implements OnInit {
  movies: Movie[];

  constructor(
    private router: Router,
    private service: MoviesService,
    private route: ActivatedRoute
    ) {}

  selectMovie(movie: Movie): void {
    this.router.navigate(['/', 'movies', movie.id]);
  }

  loadMovies(): void {
    this.movies = this.route.snapshot.data['movies'] as Movie[];
  }

  public ngOnInit(): void {
      this.loadMovies();
  }
}
