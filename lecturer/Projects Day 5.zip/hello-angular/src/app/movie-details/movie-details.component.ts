import { AuthenticationService } from './../services/authentication.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MoviesService } from '../services/movies.service';
import { Movie } from './../model/movie';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
  selectedMovie: Movie;
  canNext = false;
  canPrev = false;
  canEdit = false;

  constructor(
    private service: MoviesService,
    private authentication: AuthenticationService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    // register for changes in navigation params
    this.route.params.subscribe((prms: Params) => {
      // respond by reloading the data
      const newId = +prms['id'];
      this.loadData(newId);
    });

    // intial loading of current route data
    const id = +this.route.snapshot.params['id'];
    this.loadData(id);
  }

  loadData(id: number): void {
    this.authentication.isAuthenticated()
    .then(r => {
      this.canEdit = r;
    });

    this.service.getCount()
        .then(count => {
          this.canNext = id < count;
          this.canPrev = id > 1;
        });

    this.service.getMovie(id)
        .then(result => {
          this.selectedMovie = result;
        });
  }

  next(): void {
    this.router
      .navigate(['/', 'movies', this.selectedMovie.id + 1]);
  }

  prev(): void {
    this.router
    .navigate(['/', 'movies', this.selectedMovie.id - 1]);
  }

}
