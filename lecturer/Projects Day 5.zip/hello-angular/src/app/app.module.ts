import { MoviesResolver } from './services/movies-resolver.service';
import { resolve } from 'url';
import { AuthenticationService } from './services/authentication.service';
import { HttpModule } from '@angular/http';
import { MoviesService } from './services/movies.service';
import { MoviesListComponent } from './movies-list/app.movies-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { MovieEditorComponent } from './movie-editor/movie-editor.component';
import { HomePageComponent } from './home-page/home-page.component';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const appRoutes: Routes = [
  {path: '', component: HomePageComponent},
  {
    path: 'movies',
    component: MoviesListComponent,
    resolve: {movies: MoviesResolver}
  },
  {path: 'movies/:id', component: MovieDetailsComponent},
  {
    path: 'movies/:id/edit',
    component: MovieEditorComponent,
    canActivate: [AuthenticationService] },
  {path: 'not-found.html', component: PageNotFoundComponent},
  {path: '**', redirectTo: 'not-found.html'}
];

@NgModule({
  declarations: [
    AppComponent,
    MoviesListComponent,
    MovieDetailsComponent,
    MovieEditorComponent,
    HomePageComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [MoviesService, AuthenticationService, MoviesResolver],
  bootstrap: [AppComponent]
})
export class AppModule { }
