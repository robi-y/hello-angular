﻿using Movies.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Movies.Controllers
{
    [RoutePrefix("api/movies")]
    [EnableCors(origins:"http://localhost:4200", headers:"*", methods:"*")]
    public class MoviesController : ApiController
    {
        [HttpGet]
        [Route("count")]
        public IHttpActionResult GetCount()
        {
            var rep = Repository.Instance;
            var count = rep.Count;

            return Ok(count);
        }

        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetAll()
        {
            await Task.Delay(4000);
            return Ok(Repository.Instance.All);
        }

        [Route("{id:int}")]
        [HttpGet]
        public IHttpActionResult GetMovie(int id)
        {
            try
            {
                var res = Repository.Instance.Get(id);
                return Ok(res);
            }
            catch (KeyNotFoundException)
            {
                return NotFound();
            }
        }

        [Route("")]
        [HttpPost]
        public IHttpActionResult AddMovie([FromBody]Movie movie)
        {
            var res = Repository.Instance.Add(movie);

            return Created($"{Request.RequestUri}/{movie.Id}", res);
        }
    }
}
