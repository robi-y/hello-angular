﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace Movies.Models
{
    [DataContract]
    public class Movie
    {
        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string ImageUrl { get; set; }

        [DataMember]
        public double Rating { get; set; }


        public Movie()
        {

        }

        public Movie(int id, string name, string url, double rating)
        {
            Id = id;
            Name = name;
            ImageUrl = url;
            Rating = rating;
        }
    }
}