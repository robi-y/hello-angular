import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-editor',
  templateUrl: './movie-editor.component.html',
  styleUrls: ['./movie-editor.component.css']
})
export class MovieEditorComponent implements OnInit {
  movieForm = new FormGroup({
    'name': new FormControl(null, Validators.required),
    'imageUrl': new FormControl(null, [Validators.required,
    Validators.pattern(/^((http[s]?|ftp):\/)?\/?([^:\/\s]+)((\/\w+)*\/)([\w\-\.]+[^#?\s]+)(.*)?(#[\w\-]+)?$/)])
  });

  constructor() { }

  onSubmit(): void {
    console.log(this.movieForm);
  }

  ngOnInit() {
  }

}
