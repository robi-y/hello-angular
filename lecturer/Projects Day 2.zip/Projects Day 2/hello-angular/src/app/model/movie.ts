export class Movie {
  name: string;
  id: number;
  rating: number;
  imageUrl: string;
}
